import type { FuelApiPort } from "@/core/ports/fuel-api-port";
import type {
  AdjustedCbRow,
  ApplyBankResponse,
  BankSurplusResponse,
  ComparisonResponse,
  ComplianceCbRow,
  PoolCreateResponse,
  RouteRow,
} from "@/core/domain/types";

async function parseJson<T>(res: Response): Promise<T> {
  const text = await res.text();
  if (!res.ok) {
    let msg = res.statusText;
    try {
      const j = JSON.parse(text) as { error?: string };
      if (j.error) msg = j.error;
    } catch {
      /* ignore */
    }
    throw new Error(msg);
  }
  return text ? (JSON.parse(text) as T) : ({} as T);
}

export function createHttpFuelApi(baseUrl: string): FuelApiPort {
  const root = baseUrl.replace(/\/$/, "");

  return {
    async listRoutes() {
      const res = await fetch(`${root}/routes`);
      return parseJson<RouteRow[]>(res);
    },
    async setBaseline(routeId: string) {
      const res = await fetch(`${root}/routes/${encodeURIComponent(routeId)}/baseline`, {
        method: "POST",
      });
      await parseJson<{ ok: boolean }>(res);
    },
    async getComparison() {
      const res = await fetch(`${root}/routes/comparison`);
      return parseJson<ComparisonResponse>(res);
    },
    async getComplianceCb(year: number, shipId?: string) {
      const q = new URLSearchParams({ year: String(year) });
      if (shipId) q.set("shipId", shipId);
      const res = await fetch(`${root}/compliance/cb?${q}`);
      return parseJson<ComplianceCbRow | ComplianceCbRow[]>(res);
    },
    async getAdjustedCb(year: number, shipId?: string) {
      const q = new URLSearchParams({ year: String(year) });
      if (shipId) q.set("shipId", shipId);
      const res = await fetch(`${root}/compliance/adjusted-cb?${q}`);
      return parseJson<AdjustedCbRow | AdjustedCbRow[]>(res);
    },
    async bankSurplus(body) {
      const res = await fetch(`${root}/banking/bank`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      return parseJson<BankSurplusResponse>(res);
    },
    async applyBanked(body) {
      const res = await fetch(`${root}/banking/apply`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      return parseJson<ApplyBankResponse>(res);
    },
    async createPool(body) {
      const res = await fetch(`${root}/pools`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      return parseJson<PoolCreateResponse>(res);
    },
  };
}
