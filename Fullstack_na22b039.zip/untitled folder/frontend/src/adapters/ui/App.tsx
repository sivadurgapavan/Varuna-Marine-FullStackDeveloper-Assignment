import { useMemo, useState } from "react";
import { createHttpFuelApi } from "@/adapters/infrastructure/http-fuel-api";
import type { FuelApiPort } from "@/core/ports/fuel-api-port";
import { BankingTab } from "./tabs/BankingTab";
import { CompareTab } from "./tabs/CompareTab";
import { PoolingTab } from "./tabs/PoolingTab";
import { RoutesTab } from "./tabs/RoutesTab";

const tabs = [
  { id: "routes" as const, label: "Routes" },
  { id: "compare" as const, label: "Compare" },
  { id: "banking" as const, label: "Banking" },
  { id: "pooling" as const, label: "Pooling" },
];

export function App() {
  const api: FuelApiPort = useMemo(() => {
    const base =
      import.meta.env.VITE_API_URL?.replace(/\/$/, "") ?? "http://localhost:4000";
    return createHttpFuelApi(base);
  }, []);

  const [tab, setTab] = useState<(typeof tabs)[number]["id"]>("routes");

  return (
    <div className="min-h-screen bg-slate-950">
      <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-6 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-xl font-semibold tracking-tight text-white">
              Fuel EU Maritime
            </h1>
            <p className="text-sm text-slate-400">
              Compliance dashboard — routes, comparison, banking (Art. 20), pooling
              (Art. 21)
            </p>
          </div>
          <p className="text-xs text-slate-500">
            API:{" "}
            <code className="rounded bg-slate-800 px-1.5 py-0.5 text-slate-300">
              {import.meta.env.VITE_API_URL ?? "http://localhost:4000"}
            </code>
          </p>
        </div>
        <nav
          className="mx-auto flex max-w-6xl gap-1 px-4 pb-4"
          role="tablist"
          aria-label="Dashboard sections"
        >
          {tabs.map((t) => (
            <button
              key={t.id}
              type="button"
              role="tab"
              aria-selected={tab === t.id}
              className={`rounded-lg px-4 py-2 text-sm font-medium transition ${
                tab === t.id
                  ? "bg-cyan-600 text-white shadow"
                  : "text-slate-400 hover:bg-slate-800 hover:text-white"
              }`}
              onClick={() => setTab(t.id)}
            >
              {t.label}
            </button>
          ))}
        </nav>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8">
        {tab === "routes" && <RoutesTab api={api} />}
        {tab === "compare" && <CompareTab api={api} />}
        {tab === "banking" && <BankingTab api={api} />}
        {tab === "pooling" && <PoolingTab api={api} />}
      </main>
    </div>
  );
}
