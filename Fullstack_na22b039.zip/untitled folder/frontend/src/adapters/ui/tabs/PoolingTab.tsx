import { useCallback, useEffect, useMemo, useState } from "react";
import type { FuelApiPort } from "@/core/ports/fuel-api-port";
import type { AdjustedCbRow, PoolCreateResponse } from "@/core/domain/types";

type Props = { api: FuelApiPort };

export function PoolingTab({ api }: Props) {
  const [year, setYear] = useState(2024);
  const [rows, setRows] = useState<AdjustedCbRow[]>([]);
  const [selected, setSelected] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<PoolCreateResponse | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getAdjustedCb(year);
      const list = Array.isArray(res) ? res : [res];
      setRows(list);
      setSelected({});
      setResult(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load adjusted CB");
    } finally {
      setLoading(false);
    }
  }, [api, year]);

  useEffect(() => {
    void load();
  }, [load]);

  const members = useMemo(() => {
    return rows
      .filter((r) => selected[r.shipId])
      .map((r) => ({
        shipId: r.shipId,
        cbBefore: r.adjustedComplianceGco2eq,
      }));
  }, [rows, selected]);

  const poolSum = useMemo(
    () => members.reduce((s, m) => s + m.cbBefore, 0),
    [members]
  );

  const canCreate =
    members.length >= 2 && poolSum >= -1e-6 && !loading;

  function toggle(shipId: string) {
    setSelected((s) => ({ ...s, [shipId]: !s[shipId] }));
  }

  async function onCreate() {
    setError(null);
    try {
      const r = await api.createPool({ year, members });
      setResult(r);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Pool creation failed");
    }
  }

  return (
    <section aria-labelledby="pool-heading" className="space-y-6">
      <div>
        <h2 id="pool-heading" className="text-lg font-semibold text-white">
          Pooling (Article 21)
        </h2>
        <p className="text-sm text-slate-400">
          <code className="text-cyan-400">GET /compliance/adjusted-cb</code> → select
          ships → <code className="text-cyan-400">POST /pools</code>
        </p>
      </div>

      <label className="flex max-w-xs flex-col gap-1 text-xs text-slate-400">
        Year
        <input
          type="number"
          className="rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white"
          value={year}
          onChange={(e) => setYear(Number(e.target.value))}
        />
      </label>

      {error && (
        <div
          role="alert"
          className="rounded-lg border border-red-900/60 bg-red-950/40 px-4 py-3 text-sm text-red-200"
        >
          {error}
        </div>
      )}

      <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/50">
        <table className="min-w-full text-left text-sm">
          <thead className="border-b border-slate-800 bg-slate-900 text-xs uppercase tracking-wide text-slate-400">
            <tr>
              <th className="px-4 py-3">include</th>
              <th className="px-4 py-3">shipId</th>
              <th className="px-4 py-3">routeId</th>
              <th className="px-4 py-3">raw CB</th>
              <th className="px-4 py-3">adjusted CB (before)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {loading ? (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-slate-500">
                  Loading…
                </td>
              </tr>
            ) : (
              rows.map((r) => (
                <tr key={r.shipId}>
                  <td className="px-4 py-3">
                    <input
                      type="checkbox"
                      checked={!!selected[r.shipId]}
                      onChange={() => toggle(r.shipId)}
                      aria-label={`Include ${r.shipId}`}
                    />
                  </td>
                  <td className="px-4 py-3 font-mono text-cyan-300">{r.shipId}</td>
                  <td className="px-4 py-3 font-mono">{r.routeId}</td>
                  <td className="px-4 py-3">{r.complianceBalanceGco2eq.toFixed(2)}</td>
                  <td className="px-4 py-3">{r.adjustedComplianceGco2eq.toFixed(2)}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap items-center gap-4">
        <div
          className={`rounded-lg px-4 py-2 text-sm font-medium ${
            poolSum >= 0 ? "bg-emerald-950/50 text-emerald-300" : "bg-red-950/50 text-red-300"
          }`}
        >
          Pool sum (selected): {poolSum.toFixed(2)} gCO₂eq
        </div>
        <button
          type="button"
          disabled={!canCreate}
          className="rounded-lg bg-cyan-600 px-4 py-2 text-sm font-medium text-white hover:bg-cyan-500 disabled:cursor-not-allowed disabled:opacity-40"
          onClick={() => void onCreate()}
        >
          Create pool
        </button>
      </div>

      {result && (
        <div className="rounded-xl border border-slate-700 bg-slate-900/60 p-4">
          <p className="text-sm font-medium text-white">Pool {result.poolId}</p>
          <ul className="mt-2 space-y-1 text-sm text-slate-300">
            {result.members.map((m) => (
              <li key={m.shipId}>
                <span className="font-mono text-cyan-300">{m.shipId}</span>: before{" "}
                {m.cbBefore.toFixed(2)} → after {m.cbAfter.toFixed(2)}
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}
