import { useCallback, useEffect, useMemo, useState } from "react";
import type { FuelApiPort } from "@/core/ports/fuel-api-port";
import type { ComplianceCbRow } from "@/core/domain/types";
import { fmtGco2eq } from "@/shared/format";

type Props = { api: FuelApiPort };

export function BankingTab({ api }: Props) {
  const [year, setYear] = useState(2024);
  const [shipId, setShipId] = useState("S001");
  const [rows, setRows] = useState<ComplianceCbRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [applyAmount, setApplyAmount] = useState("");
  const [lastAction, setLastAction] = useState<{
    cbBefore: number;
    applied?: number;
    banked?: number;
    cbAfter: number;
  } | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getComplianceCb(year);
      const list = Array.isArray(res) ? res : [res];
      setRows(list);
      if (!list.find((r) => r.shipId === shipId) && list[0]) {
        setShipId(list[0].shipId);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load CB");
    } finally {
      setLoading(false);
    }
  }, [api, year]);

  useEffect(() => {
    void load();
  }, [load]);

  const current = useMemo(
    () => rows.find((r) => r.shipId === shipId),
    [rows, shipId]
  );

  const cbValue = current?.complianceBalanceGco2eq ?? 0;
  const canBank = cbValue > 0;
  const canApply = cbValue < 0;

  async function onBank() {
    setError(null);
    try {
      const r = await api.bankSurplus({ shipId, year });
      setLastAction({
        cbBefore: r.cbBefore,
        banked: r.banked,
        cbAfter: r.cbAfter,
      });
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Bank failed");
    }
  }

  async function onApply() {
    const amt = Number(applyAmount);
    if (!Number.isFinite(amt) || amt <= 0) {
      setError("Enter a positive apply amount");
      return;
    }
    setError(null);
    try {
      const r = await api.applyBanked({ shipId, year, amount: amt });
      setLastAction({
        cbBefore: r.cbBefore,
        applied: r.applied,
        cbAfter: r.cbAfter,
      });
      setApplyAmount("");
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Apply failed");
    }
  }

  return (
    <section aria-labelledby="bank-heading" className="space-y-6">
      <div>
        <h2 id="bank-heading" className="text-lg font-semibold text-white">
          Banking (Article 20)
        </h2>
        <p className="text-sm text-slate-400">
          <code className="text-cyan-400">GET /compliance/cb</code>,{" "}
          <code className="text-cyan-400">POST /banking/bank</code>,{" "}
          <code className="text-cyan-400">POST /banking/apply</code>
        </p>
      </div>

      <div className="flex flex-wrap gap-3">
        <label className="flex flex-col gap-1 text-xs text-slate-400">
          Year
          <input
            type="number"
            className="rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white"
            value={year}
            onChange={(e) => setYear(Number(e.target.value))}
          />
        </label>
        <label className="flex flex-col gap-1 text-xs text-slate-400">
          Ship
          <select
            className="rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white"
            value={shipId}
            onChange={(e) => setShipId(e.target.value)}
            disabled={!rows.length}
          >
            {rows.map((r) => (
              <option key={r.shipId} value={r.shipId}>
                {r.shipId} ({r.routeId})
              </option>
            ))}
          </select>
        </label>
      </div>

      {!loading && rows.length === 0 && (
        <p className="text-sm text-slate-500">
          No routes for this year — adjust year or ensure the API is seeded.
        </p>
      )}

      {error && (
        <div
          role="alert"
          className="rounded-lg border border-red-900/60 bg-red-950/40 px-4 py-3 text-sm text-red-200"
        >
          {error}
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <p className="text-xs uppercase text-slate-500">Current CB (gCO₂eq)</p>
          <p className="mt-1 text-2xl font-semibold text-white">
            {loading ? "…" : fmtGco2eq(cbValue)}
          </p>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <p className="text-xs uppercase text-slate-500">Last cb_before</p>
          <p className="mt-1 text-2xl font-semibold text-white">
            {lastAction ? fmtGco2eq(lastAction.cbBefore) : "—"}
          </p>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4">
          <p className="text-xs uppercase text-slate-500">Last applied / banked</p>
          <p className="mt-1 text-2xl font-semibold text-cyan-300">
            {lastAction?.applied !== undefined
              ? fmtGco2eq(lastAction.applied)
              : lastAction?.banked !== undefined
                ? fmtGco2eq(lastAction.banked)
                : "—"}
          </p>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 sm:col-span-3">
          <p className="text-xs uppercase text-slate-500">Last cb_after</p>
          <p className="mt-1 text-2xl font-semibold text-emerald-300">
            {lastAction ? fmtGco2eq(lastAction.cbAfter) : "—"}
          </p>
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        <button
          type="button"
          disabled={!canBank || loading}
          className="rounded-lg bg-cyan-600 px-4 py-2 text-sm font-medium text-white hover:bg-cyan-500 disabled:cursor-not-allowed disabled:opacity-40"
          onClick={() => void onBank()}
        >
          Bank surplus
        </button>
        <div className="flex items-end gap-2">
          <label className="flex flex-col gap-1 text-xs text-slate-400">
            Apply amount
            <input
              type="number"
              className="w-40 rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white"
              value={applyAmount}
              onChange={(e) => setApplyAmount(e.target.value)}
              placeholder="gCO₂eq"
            />
          </label>
          <button
            type="button"
            disabled={!canApply || loading}
            className="rounded-lg bg-slate-700 px-4 py-2 text-sm font-medium text-white hover:bg-slate-600 disabled:cursor-not-allowed disabled:opacity-40"
            onClick={() => void onApply()}
          >
            Apply banked
          </button>
        </div>
      </div>
    </section>
  );
}
