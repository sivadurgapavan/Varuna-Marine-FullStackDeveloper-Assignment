import { useCallback, useEffect, useMemo, useState } from "react";
import type { FuelApiPort } from "@/core/ports/fuel-api-port";
import type { RouteRow } from "@/core/domain/types";

type Props = { api: FuelApiPort };

export function RoutesTab({ api }: Props) {
  const [routes, setRoutes] = useState<RouteRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const [vesselType, setVesselType] = useState<string>("");
  const [fuelType, setFuelType] = useState<string>("");
  const [year, setYear] = useState<string>("");

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.listRoutes();
      setRoutes(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load routes");
    } finally {
      setLoading(false);
    }
  }, [api]);

  useEffect(() => {
    void load();
  }, [load]);

  const vesselTypes = useMemo(
    () => [...new Set(routes.map((r) => r.vesselType))].sort(),
    [routes]
  );
  const fuelTypes = useMemo(
    () => [...new Set(routes.map((r) => r.fuelType))].sort(),
    [routes]
  );
  const years = useMemo(
    () => [...new Set(routes.map((r) => r.year))].sort((a, b) => a - b),
    [routes]
  );

  const filtered = useMemo(() => {
    return routes.filter((r) => {
      if (vesselType && r.vesselType !== vesselType) return false;
      if (fuelType && r.fuelType !== fuelType) return false;
      if (year && String(r.year) !== year) return false;
      return true;
    });
  }, [routes, vesselType, fuelType, year]);

  async function onBaseline(routeId: string) {
    setBusy(routeId);
    setError(null);
    try {
      await api.setBaseline(routeId);
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Baseline failed");
    } finally {
      setBusy(null);
    }
  }

  return (
    <section aria-labelledby="routes-heading" className="space-y-6">
      <div>
        <h2 id="routes-heading" className="text-lg font-semibold text-white">
          Routes
        </h2>
        <p className="text-sm text-slate-400">
          Fleet routes from <code className="text-cyan-400">GET /routes</code>.
          Set the baseline route for comparison.
        </p>
      </div>

      <div className="flex flex-wrap gap-3">
        <label className="flex flex-col gap-1 text-xs text-slate-400">
          Vessel type
          <select
            className="rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white"
            value={vesselType}
            onChange={(e) => setVesselType(e.target.value)}
          >
            <option value="">All</option>
            {vesselTypes.map((v) => (
              <option key={v} value={v}>
                {v}
              </option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1 text-xs text-slate-400">
          Fuel type
          <select
            className="rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white"
            value={fuelType}
            onChange={(e) => setFuelType(e.target.value)}
          >
            <option value="">All</option>
            {fuelTypes.map((f) => (
              <option key={f} value={f}>
                {f}
              </option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1 text-xs text-slate-400">
          Year
          <select
            className="rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-white"
            value={year}
            onChange={(e) => setYear(e.target.value)}
          >
            <option value="">All</option>
            {years.map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
        </label>
      </div>

      {error && (
        <div
          role="alert"
          className="rounded-lg border border-red-900/60 bg-red-950/40 px-4 py-3 text-sm text-red-200"
        >
          {error}
        </div>
      )}

      <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/50">
        <table className="min-w-full text-left text-sm">
          <thead className="border-b border-slate-800 bg-slate-900 text-xs uppercase tracking-wide text-slate-400">
            <tr>
              <th className="px-4 py-3">routeId</th>
              <th className="px-4 py-3">vesselType</th>
              <th className="px-4 py-3">fuelType</th>
              <th className="px-4 py-3">year</th>
              <th className="px-4 py-3">ghgIntensity</th>
              <th className="px-4 py-3">fuelConsumption (t)</th>
              <th className="px-4 py-3">distance (km)</th>
              <th className="px-4 py-3">totalEmissions (t)</th>
              <th className="px-4 py-3">baseline</th>
              <th className="px-4 py-3">actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {loading ? (
              <tr>
                <td colSpan={10} className="px-4 py-8 text-center text-slate-500">
                  Loading…
                </td>
              </tr>
            ) : (
              filtered.map((r) => (
                <tr key={r.routeId} className="hover:bg-slate-800/40">
                  <td className="px-4 py-3 font-mono text-cyan-300">{r.routeId}</td>
                  <td className="px-4 py-3">{r.vesselType}</td>
                  <td className="px-4 py-3">{r.fuelType}</td>
                  <td className="px-4 py-3">{r.year}</td>
                  <td className="px-4 py-3">{r.ghgIntensity.toFixed(4)}</td>
                  <td className="px-4 py-3">{r.fuelConsumption}</td>
                  <td className="px-4 py-3">{r.distance}</td>
                  <td className="px-4 py-3">{r.totalEmissions}</td>
                  <td className="px-4 py-3">
                    {r.isBaseline ? (
                      <span className="rounded bg-emerald-900/50 px-2 py-0.5 text-emerald-300">
                        yes
                      </span>
                    ) : (
                      <span className="text-slate-500">no</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <button
                      type="button"
                      disabled={busy === r.routeId}
                      className="rounded-md bg-slate-800 px-3 py-1.5 text-xs font-medium text-white hover:bg-slate-700 disabled:opacity-50"
                      onClick={() => void onBaseline(r.routeId)}
                    >
                      {busy === r.routeId ? "…" : "Set Baseline"}
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}
