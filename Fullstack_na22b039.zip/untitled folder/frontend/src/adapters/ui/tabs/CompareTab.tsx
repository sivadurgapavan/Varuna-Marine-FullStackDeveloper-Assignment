import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { FuelApiPort } from "@/core/ports/fuel-api-port";
import type { ComparisonResponse } from "@/core/domain/types";

type Props = { api: FuelApiPort };

export function CompareTab({ api }: Props) {
  const [data, setData] = useState<ComparisonResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getComparison();
      setData(res);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load comparison");
    } finally {
      setLoading(false);
    }
  }, [api]);

  useEffect(() => {
    void load();
  }, [load]);

  const chartData = useMemo(() => {
    if (!data) return [];
    return [
      { label: data.baseline.routeId, ghgIntensity: data.baseline.ghgIntensity },
      ...data.comparisons.map((c) => ({
        label: c.routeId,
        ghgIntensity: c.ghgIntensity,
      })),
    ];
  }, [data]);

  return (
    <section aria-labelledby="compare-heading" className="space-y-6">
      <div>
        <h2 id="compare-heading" className="text-lg font-semibold text-white">
          Compare
        </h2>
        <p className="text-sm text-slate-400">
          Baseline vs other routes from{" "}
          <code className="text-cyan-400">GET /routes/comparison</code>. Target
          intensity: {data?.targetIntensity.toFixed(4) ?? "—"} gCO₂e/MJ.
        </p>
      </div>

      {error && (
        <div
          role="alert"
          className="rounded-lg border border-red-900/60 bg-red-950/40 px-4 py-3 text-sm text-red-200"
        >
          {error}
        </div>
      )}

      {loading || !data ? (
        <p className="text-slate-500">Loading comparison…</p>
      ) : (
        <>
          <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/50">
            <table className="min-w-full text-left text-sm">
              <thead className="border-b border-slate-800 bg-slate-900 text-xs uppercase tracking-wide text-slate-400">
                <tr>
                  <th className="px-4 py-3">routeId</th>
                  <th className="px-4 py-3">ghgIntensity</th>
                  <th className="px-4 py-3">% diff vs baseline</th>
                  <th className="px-4 py-3">compliant (≤ target)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                <tr className="bg-slate-800/30">
                  <td className="px-4 py-3 font-mono text-amber-300">
                    {data.baseline.routeId} (baseline)
                  </td>
                  <td className="px-4 py-3">{data.baseline.ghgIntensity.toFixed(4)}</td>
                  <td className="px-4 py-3 text-slate-500">—</td>
                  <td className="px-4 py-3">
                    {data.baseline.ghgIntensity <= data.targetIntensity ? "✓" : "✗"}
                  </td>
                </tr>
                {data.comparisons.map((c) => (
                  <tr key={c.routeId}>
                    <td className="px-4 py-3 font-mono text-cyan-300">{c.routeId}</td>
                    <td className="px-4 py-3">{c.ghgIntensity.toFixed(4)}</td>
                    <td className="px-4 py-3">{c.percentDiff.toFixed(2)}%</td>
                    <td className="px-4 py-3">{c.compliant ? "✓" : "✗"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="h-80 w-full rounded-xl border border-slate-800 bg-slate-900/50 p-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="label" tick={{ fill: "#94a3b8", fontSize: 12 }} />
                <YAxis
                  tick={{ fill: "#94a3b8", fontSize: 12 }}
                  label={{
                    value: "gCO₂e/MJ",
                    angle: -90,
                    position: "insideLeft",
                    fill: "#94a3b8",
                  }}
                />
                <Tooltip
                  contentStyle={{
                    background: "#0f172a",
                    border: "1px solid #334155",
                    borderRadius: 8,
                  }}
                />
                <Legend />
                <ReferenceLine
                  y={data.targetIntensity}
                  stroke="#22d3ee"
                  strokeDasharray="4 4"
                  label={{ value: "Target", fill: "#22d3ee", position: "top" }}
                />
                <Bar dataKey="ghgIntensity" name="GHG intensity" fill="#06b6d4" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </>
      )}
    </section>
  );
}
