import type {
  AdjustedCbRow,
  ApplyBankResponse,
  BankSurplusResponse,
  ComparisonResponse,
  ComplianceCbRow,
  PoolCreateResponse,
  RouteRow,
} from "../domain/types";

export interface FuelApiPort {
  listRoutes(): Promise<RouteRow[]>;
  setBaseline(routeId: string): Promise<void>;
  getComparison(): Promise<ComparisonResponse>;
  getComplianceCb(year: number, shipId?: string): Promise<ComplianceCbRow | ComplianceCbRow[]>;
  getAdjustedCb(year: number, shipId?: string): Promise<AdjustedCbRow | AdjustedCbRow[]>;
  bankSurplus(body: {
    shipId: string;
    year: number;
    amount?: number;
  }): Promise<BankSurplusResponse>;
  applyBanked(body: {
    shipId: string;
    year: number;
    amount: number;
  }): Promise<ApplyBankResponse>;
  createPool(body: {
    year: number;
    members: { shipId: string; cbBefore: number }[];
  }): Promise<PoolCreateResponse>;
}
