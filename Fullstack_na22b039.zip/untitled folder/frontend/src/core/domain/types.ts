export type RouteRow = {
  routeId: string;
  vesselType: string;
  fuelType: string;
  year: number;
  ghgIntensity: number;
  fuelConsumption: number;
  distance: number;
  totalEmissions: number;
  isBaseline: boolean;
};

export type ComparisonResponse = {
  targetIntensity: number;
  baseline: {
    routeId: string;
    ghgIntensity: number;
    vesselType: string;
    fuelType: string;
    year: number;
  };
  comparisons: {
    routeId: string;
    vesselType: string;
    fuelType: string;
    year: number;
    ghgIntensity: number;
    percentDiff: number;
    compliant: boolean;
  }[];
};

export type ComplianceCbRow = {
  shipId: string;
  routeId: string;
  year: number;
  ghgIntensity: number;
  fuelConsumption: number;
  complianceBalanceGco2eq: number;
};

export type AdjustedCbRow = {
  shipId: string;
  routeId: string;
  year: number;
  complianceBalanceGco2eq: number;
  adjustedComplianceGco2eq: number;
};

export type BankSurplusResponse = {
  cbBefore: number;
  banked: number;
  cbAfter: number;
  fleetBankBalance: number;
};

export type ApplyBankResponse = {
  cbBefore: number;
  applied: number;
  cbAfter: number;
  fleetBankBalance: number;
};

export type PoolCreateResponse = {
  poolId: string;
  members: { shipId: string; cbBefore: number; cbAfter: number }[];
};
