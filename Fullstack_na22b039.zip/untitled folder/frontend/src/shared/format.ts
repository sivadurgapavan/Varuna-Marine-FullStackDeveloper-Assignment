/** Compact display for large gCO₂eq values */
export function fmtGco2eq(n: number): string {
  if (Math.abs(n) >= 1e9) return `${(n / 1e9).toFixed(3)}B`;
  if (Math.abs(n) >= 1e6) return `${(n / 1e6).toFixed(3)}M`;
  if (Math.abs(n) >= 1e3) return `${(n / 1e3).toFixed(3)}k`;
  return n.toFixed(2);
}
