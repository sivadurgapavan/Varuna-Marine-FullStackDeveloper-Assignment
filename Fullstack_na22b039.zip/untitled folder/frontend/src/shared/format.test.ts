import { describe, expect, it } from "vitest";
import { fmtGco2eq } from "./format";

describe("fmtGco2eq", () => {
  it("abbreviates large magnitudes", () => {
    expect(fmtGco2eq(1.5e9)).toContain("B");
    expect(fmtGco2eq(2e6)).toContain("M");
  });
});
