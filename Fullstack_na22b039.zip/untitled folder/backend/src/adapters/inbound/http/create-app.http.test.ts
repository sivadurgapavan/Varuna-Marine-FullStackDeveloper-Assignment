import request from "supertest";
import { describe, expect, it } from "vitest";
import { createApp } from "./create-app.js";
import {
  createInMemoryBankRepo,
  createInMemoryComplianceRepo,
  createInMemoryPoolRepo,
  createInMemoryRouteRepo,
  sampleRoute,
} from "../../../test/in-memory-repos.js";

function buildApp() {
  const routes = [
    { ...sampleRoute },
    {
      ...sampleRoute,
      id: "r2",
      routeId: "R002",
      shipId: "S002",
      isBaseline: false,
      ghgIntensity: 88,
    },
  ];
  return createApp({
    routeRepo: createInMemoryRouteRepo(routes),
    complianceRepo: createInMemoryComplianceRepo(),
    bankRepo: createInMemoryBankRepo(),
    poolRepo: createInMemoryPoolRepo(),
  });
}

describe("HTTP API (supertest)", () => {
  it("GET /routes returns rows", async () => {
    const res = await request(buildApp()).get("/routes");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body[0]).toHaveProperty("routeId");
  });

  it("GET /routes/comparison requires baseline", async () => {
    const res = await request(buildApp()).get("/routes/comparison");
    expect(res.status).toBe(200);
    expect(res.body.baseline.routeId).toBe("R001");
  });

  it("POST /routes/:id/baseline", async () => {
    const res = await request(buildApp()).post("/routes/R002/baseline");
    expect(res.status).toBe(200);
  });
});
