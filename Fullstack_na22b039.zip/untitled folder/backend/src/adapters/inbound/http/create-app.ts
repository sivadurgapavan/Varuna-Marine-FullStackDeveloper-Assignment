import cors from "cors";
import express, { type Express } from "express";
import { TARGET_INTENSITY_GCO2E_PER_MJ } from "../../../core/domain/constants.js";
import { bankSurplus, applyBankedSurplus } from "../../../core/application/bank-use-cases.js";
import {
  buildComparisonRows,
  computeRouteComplianceCb,
  adjustedComplianceForShipYear,
  getOrCreateComplianceSnapshot,
} from "../../../core/application/compliance-service.js";
import { createPool } from "../../../core/application/create-pool-use-case.js";
import type {
  BankRepository,
  ComplianceRepository,
  PoolRepository,
  RouteRepository,
} from "../../../core/ports/repositories.js";

export type AppDeps = {
  routeRepo: RouteRepository;
  complianceRepo: ComplianceRepository;
  bankRepo: BankRepository;
  poolRepo: PoolRepository;
};

export function createApp(deps: AppDeps): Express {
  const app = express();
  app.use(cors());
  app.use(express.json());

  app.get("/health", (_req, res) => {
    res.json({ ok: true });
  });

  app.get("/routes", async (_req, res) => {
    const routes = await deps.routeRepo.findAll();
    res.json(
      routes.map((r) => ({
        routeId: r.routeId,
        vesselType: r.vesselType,
        fuelType: r.fuelType,
        year: r.year,
        ghgIntensity: r.ghgIntensity,
        fuelConsumption: r.fuelConsumption,
        distance: r.distance,
        totalEmissions: r.totalEmissions,
        isBaseline: r.isBaseline,
      }))
    );
  });

  app.post("/routes/:routeId/baseline", async (req, res) => {
    const { routeId } = req.params;
    const existing = await deps.routeRepo.findByRouteId(routeId);
    if (!existing) {
      res.status(404).json({ error: `Route ${routeId} not found` });
      return;
    }
    await deps.routeRepo.setBaseline(routeId);
    res.json({ ok: true, routeId });
  });

  app.get("/routes/comparison", async (_req, res) => {
    const baseline = await deps.routeRepo.findBaseline();
    if (!baseline) {
      res.status(400).json({ error: "No baseline route set" });
      return;
    }
    const all = await deps.routeRepo.findAll();
    const others = all.filter((r) => r.routeId !== baseline.routeId);
    const rows = buildComparisonRows(baseline, others);
    res.json({
      targetIntensity: TARGET_INTENSITY_GCO2E_PER_MJ,
      baseline: {
        routeId: baseline.routeId,
        ghgIntensity: baseline.ghgIntensity,
        vesselType: baseline.vesselType,
        fuelType: baseline.fuelType,
        year: baseline.year,
      },
      comparisons: rows,
    });
  });

  app.get("/compliance/cb", async (req, res) => {
    const year = Number(req.query.year);
    const shipId = req.query.shipId as string | undefined;
    if (!Number.isFinite(year)) {
      res.status(400).json({ error: "Query year is required" });
      return;
    }
    const routes = await deps.routeRepo.findAll();
    const forYear = routes.filter((r) => r.year === year);
    const targets = shipId
      ? forYear.filter((r) => r.shipId === shipId)
      : forYear;
    if (!targets.length) {
      res.status(404).json({ error: "No routes for filter" });
      return;
    }
    const out = [];
    for (const route of targets) {
      const cb = await getOrCreateComplianceSnapshot(deps.complianceRepo, route);
      out.push({
        shipId: route.shipId,
        routeId: route.routeId,
        year: route.year,
        ghgIntensity: route.ghgIntensity,
        fuelConsumption: route.fuelConsumption,
        complianceBalanceGco2eq: cb,
      });
    }
    res.json(shipId ? out[0] : out);
  });

  app.get("/compliance/adjusted-cb", async (req, res) => {
    const year = Number(req.query.year);
    const shipId = req.query.shipId as string | undefined;
    if (!Number.isFinite(year)) {
      res.status(400).json({ error: "Query year is required" });
      return;
    }
    const routes = await deps.routeRepo.findAll();
    const forYear = routes.filter((r) => r.year === year);
    const targets = shipId
      ? forYear.filter((r) => r.shipId === shipId)
      : forYear;
    if (!targets.length) {
      res.status(404).json({ error: "No routes for filter" });
      return;
    }
    const out = [];
    for (const route of targets) {
      const raw = computeRouteComplianceCb(route);
      await deps.complianceRepo.upsertSnapshot(route.shipId, route.year, raw);
      const adjusted = await adjustedComplianceForShipYear(
        raw,
        deps.bankRepo,
        route.shipId,
        route.year
      );
      out.push({
        shipId: route.shipId,
        routeId: route.routeId,
        year: route.year,
        complianceBalanceGco2eq: raw,
        adjustedComplianceGco2eq: adjusted,
      });
    }
    res.json(shipId ? out[0] : out);
  });

  app.get("/banking/records", async (req, res) => {
    const year = Number(req.query.year);
    const shipId = req.query.shipId as string | undefined;
    if (!shipId || !Number.isFinite(year)) {
      res.status(400).json({ error: "shipId and year are required" });
      return;
    }
    const records = await deps.bankRepo.listForShipYear(shipId, year);
    res.json({ records });
  });

  app.post("/banking/bank", async (req, res) => {
    try {
      const { shipId, year, amount } = req.body as {
        shipId?: string;
        year?: number;
        amount?: number;
      };
      if (!shipId || !Number.isFinite(year)) {
        res.status(400).json({ error: "shipId and year are required" });
        return;
      }
      const result = await bankSurplus(
        deps.routeRepo,
        deps.complianceRepo,
        deps.bankRepo,
        shipId,
        year as number,
        amount
      );
      res.json(result);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Error";
      res.status(400).json({ error: msg });
    }
  });

  app.post("/banking/apply", async (req, res) => {
    try {
      const { shipId, year, amount } = req.body as {
        shipId?: string;
        year?: number;
        amount?: number;
      };
      if (!shipId || !Number.isFinite(year) || !Number.isFinite(amount)) {
        res
          .status(400)
          .json({ error: "shipId, year, and amount are required" });
        return;
      }
      const result = await applyBankedSurplus(
        deps.routeRepo,
        deps.complianceRepo,
        deps.bankRepo,
        shipId,
        year as number,
        amount as number
      );
      res.json(result);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Error";
      res.status(400).json({ error: msg });
    }
  });

  app.post("/pools", async (req, res) => {
    try {
      const body = req.body as {
        year?: number;
        members?: { shipId: string; cbBefore: number }[];
      };
      if (!Number.isFinite(body.year) || !Array.isArray(body.members)) {
        res.status(400).json({ error: "year and members[] are required" });
        return;
      }
      const result = await createPool(
        deps.poolRepo,
        body.year as number,
        body.members as { shipId: string; cbBefore: number }[]
      );
      res.json(result);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Error";
      res.status(400).json({ error: msg });
    }
  });

  return app;
}
