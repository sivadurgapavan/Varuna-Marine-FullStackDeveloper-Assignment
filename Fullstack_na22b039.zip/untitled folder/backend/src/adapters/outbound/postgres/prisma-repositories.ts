import { PrismaClient } from "@prisma/client";
import { BANK_ENTRY_APPLY, BANK_ENTRY_BANK } from "../../../core/domain/constants.js";
import type {
  BankEntryRecord,
  BankRepository,
  ComplianceRepository,
  PoolRepository,
  RouteRecord,
  RouteRepository,
} from "../../../core/ports/repositories.js";

function mapRoute(r: {
  id: string;
  routeId: string;
  shipId: string;
  vesselType: string;
  fuelType: string;
  year: number;
  ghgIntensity: number;
  fuelConsumption: number;
  distance: number;
  totalEmissions: number;
  isBaseline: boolean;
}): RouteRecord {
  return {
    id: r.id,
    routeId: r.routeId,
    shipId: r.shipId,
    vesselType: r.vesselType,
    fuelType: r.fuelType,
    year: r.year,
    ghgIntensity: r.ghgIntensity,
    fuelConsumption: r.fuelConsumption,
    distance: r.distance,
    totalEmissions: r.totalEmissions,
    isBaseline: r.isBaseline,
  };
}

export function createRouteRepository(prisma: PrismaClient): RouteRepository {
  return {
    async findAll() {
      const rows = await prisma.route.findMany({ orderBy: { routeId: "asc" } });
      return rows.map(mapRoute);
    },
    async findByRouteId(routeId: string) {
      const r = await prisma.route.findUnique({ where: { routeId } });
      return r ? mapRoute(r) : null;
    },
    async setBaseline(routeId: string) {
      await prisma.$transaction([
        prisma.route.updateMany({ data: { isBaseline: false } }),
        prisma.route.update({
          where: { routeId },
          data: { isBaseline: true },
        }),
      ]);
    },
    async findBaseline() {
      const r = await prisma.route.findFirst({ where: { isBaseline: true } });
      return r ? mapRoute(r) : null;
    },
  };
}

export function createComplianceRepository(prisma: PrismaClient): ComplianceRepository {
  return {
    async upsertSnapshot(shipId: string, year: number, cbGco2eq: number) {
      await prisma.shipCompliance.upsert({
        where: { shipId_year: { shipId, year } },
        create: { shipId, year, cbGco2eq },
        update: { cbGco2eq, computedAt: new Date() },
      });
    },
    async findSnapshot(shipId: string, year: number) {
      const row = await prisma.shipCompliance.findUnique({
        where: { shipId_year: { shipId, year } },
      });
      return row ? { cbGco2eq: row.cbGco2eq } : null;
    },
  };
}

function mapBank(e: {
  id: string;
  shipId: string;
  year: number;
  amountGco2eq: number;
  entryType: string;
  createdAt: Date;
}): BankEntryRecord {
  return {
    id: e.id,
    shipId: e.shipId,
    year: e.year,
    amountGco2eq: e.amountGco2eq,
    entryType: e.entryType,
    createdAt: e.createdAt,
  };
}

export function createBankRepository(prisma: PrismaClient): BankRepository {
  return {
    async createEntry(input) {
      const e = await prisma.bankEntry.create({ data: input });
      return mapBank(e);
    },
    async listForShipYear(shipId: string, year: number) {
      const rows = await prisma.bankEntry.findMany({
        where: { shipId, year },
        orderBy: { createdAt: "asc" },
      });
      return rows.map(mapBank);
    },
    async fleetBankBalanceForYear(year: number) {
      const [banked, applied] = await Promise.all([
        prisma.bankEntry.aggregate({
          where: { year, entryType: BANK_ENTRY_BANK },
          _sum: { amountGco2eq: true },
        }),
        prisma.bankEntry.aggregate({
          where: { year, entryType: BANK_ENTRY_APPLY },
          _sum: { amountGco2eq: true },
        }),
      ]);
      return (
        (banked._sum.amountGco2eq ?? 0) - (applied._sum.amountGco2eq ?? 0)
      );
    },
  };
}

export function createPoolRepository(prisma: PrismaClient): PoolRepository {
  return {
    async createPoolWithMembers(input) {
      const pool = await prisma.pool.create({
        data: {
          year: input.year,
          members: {
            create: input.members.map((m) => ({
              shipId: m.shipId,
              cbBefore: m.cbBefore,
              cbAfter: m.cbAfter,
            })),
          },
        },
      });
      return { poolId: pool.id };
    },
  };
}
