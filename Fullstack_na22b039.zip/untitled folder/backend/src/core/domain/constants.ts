/** Fuel EU Maritime — target intensity (2025), gCO₂e/MJ (2% below 91.16). */
export const TARGET_INTENSITY_GCO2E_PER_MJ = 89.3368;

/** Approximate energy content, MJ per tonne of fuel (assignment). */
export const MJ_PER_TONNE_FUEL = 41_000;

export const BANK_ENTRY_BANK = "BANK";
export const BANK_ENTRY_APPLY = "APPLY";
