/**
 * Greedy intra-pool transfer: sort by CB descending, move surplus to deficits.
 * Returns cb_after per member.
 */
export function allocatePoolGreedy(
  members: { shipId: string; cbBefore: number }[]
): { shipId: string; cbBefore: number; cbAfter: number }[] {
  const sorted = [...members].sort((a, b) => b.cbBefore - a.cbBefore);
  const working = sorted.map((m) => ({
    shipId: m.shipId,
    cbBefore: m.cbBefore,
    cur: m.cbBefore,
  }));
  let i = 0;
  let j = working.length - 1;
  while (i < j) {
    while (i < j && working[i].cur <= 0) i++;
    while (i < j && working[j].cur >= 0) j--;
    if (i >= j) break;
    const give = working[i].cur;
    const need = -working[j].cur;
    if (give <= 0 || need <= 0) break;
    const transfer = Math.min(give, need);
    working[i].cur -= transfer;
    working[j].cur += transfer;
  }
  return working.map((w) => ({
    shipId: w.shipId,
    cbBefore: w.cbBefore,
    cbAfter: w.cur,
  }));
}

const EPS = 1e-6;

export function validatePoolRules(
  allocated: { shipId: string; cbBefore: number; cbAfter: number }[]
): { ok: true } | { ok: false; reason: string } {
  const sum = allocated.reduce((s, m) => s + m.cbAfter, 0);
  if (sum < -EPS) {
    return { ok: false, reason: "Pool sum of CB after allocation must be ≥ 0" };
  }
  for (const m of allocated) {
    if (m.cbBefore < 0 && m.cbAfter < m.cbBefore - EPS) {
      return {
        ok: false,
        reason: `Deficit ship ${m.shipId} cannot exit worse than before pooling`,
      };
    }
    if (m.cbBefore > 0 && m.cbAfter < -EPS) {
      return {
        ok: false,
        reason: `Surplus ship ${m.shipId} cannot exit with negative CB`,
      };
    }
  }
  return { ok: true };
}
