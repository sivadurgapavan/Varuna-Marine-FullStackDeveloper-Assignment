import { describe, expect, it } from "vitest";
import { allocatePoolGreedy, validatePoolRules } from "./pool-allocation.js";

describe("allocatePoolGreedy", () => {
  it("transfers surplus to deficits", () => {
    const out = allocatePoolGreedy([
      { shipId: "A", cbBefore: 100 },
      { shipId: "B", cbBefore: -40 },
      { shipId: "C", cbBefore: -30 },
    ]);
    const sum = out.reduce((s, m) => s + m.cbAfter, 0);
    expect(sum).toBeCloseTo(30, 4);
    const byId = Object.fromEntries(out.map((m) => [m.shipId, m]));
    expect(byId.A.cbAfter).toBeGreaterThanOrEqual(0);
    expect(byId.B.cbAfter).toBeGreaterThanOrEqual(byId.B.cbBefore);
  });
});

describe("validatePoolRules", () => {
  it("rejects negative pool sum", () => {
    const r = validatePoolRules([
      { shipId: "A", cbBefore: -10, cbAfter: -20 },
    ]);
    expect(r.ok).toBe(false);
  });
});
