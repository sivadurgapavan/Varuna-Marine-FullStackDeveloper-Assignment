import { describe, expect, it } from "vitest";
import {
  computeComplianceBalanceGco2eq,
  computePercentDiffVsBaseline,
  energyInScopeMj,
  isCompliantWithTarget,
} from "./compliance.js";
import { TARGET_INTENSITY_GCO2E_PER_MJ } from "./constants.js";

describe("computeComplianceBalanceGco2eq", () => {
  it("matches assignment formula (Target − Actual) × Energy", () => {
    const fuelT = 5000;
    const actual = 91.0;
    const energy = energyInScopeMj(fuelT);
    const expected =
      (TARGET_INTENSITY_GCO2E_PER_MJ - actual) * energy;
    expect(computeComplianceBalanceGco2eq(actual, fuelT)).toBeCloseTo(
      expected,
      4
    );
  });
});

describe("computePercentDiffVsBaseline", () => {
  it("uses ((comparison / baseline) − 1) × 100", () => {
    expect(computePercentDiffVsBaseline(90, 91)).toBeCloseTo(
      (91 / 90 - 1) * 100,
      6
    );
  });
});

describe("isCompliantWithTarget", () => {
  it("is true when intensity is at or below target", () => {
    expect(isCompliantWithTarget(89)).toBe(true);
    expect(isCompliantWithTarget(TARGET_INTENSITY_GCO2E_PER_MJ)).toBe(true);
    expect(isCompliantWithTarget(91)).toBe(false);
  });
});
