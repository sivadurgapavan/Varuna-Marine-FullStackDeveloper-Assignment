import { MJ_PER_TONNE_FUEL, TARGET_INTENSITY_GCO2E_PER_MJ } from "./constants.js";

/**
 * Energy in scope (MJ) ≈ fuelConsumption (t) × 41 000 MJ/t
 */
export function energyInScopeMj(fuelConsumptionTonnes: number): number {
  return fuelConsumptionTonnes * MJ_PER_TONNE_FUEL;
}

/**
 * Compliance Balance (gCO₂eq) = (Target − Actual) × Energy in scope
 * Positive → surplus; negative → deficit.
 */
export function computeComplianceBalanceGco2eq(
  ghgIntensityGco2ePerMj: number,
  fuelConsumptionTonnes: number,
  targetIntensity: number = TARGET_INTENSITY_GCO2E_PER_MJ
): number {
  const energy = energyInScopeMj(fuelConsumptionTonnes);
  return (targetIntensity - ghgIntensityGco2ePerMj) * energy;
}

export function computePercentDiffVsBaseline(
  baselineGhg: number,
  comparisonGhg: number
): number {
  if (baselineGhg === 0) {
    throw new Error("Baseline GHG intensity cannot be zero");
  }
  return (comparisonGhg / baselineGhg - 1) * 100;
}

export function isCompliantWithTarget(
  ghgIntensityGco2ePerMj: number,
  targetIntensity: number = TARGET_INTENSITY_GCO2E_PER_MJ
): boolean {
  return ghgIntensityGco2ePerMj <= targetIntensity;
}
