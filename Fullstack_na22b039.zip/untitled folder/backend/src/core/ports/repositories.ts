export type RouteRecord = {
  id: string;
  routeId: string;
  shipId: string;
  vesselType: string;
  fuelType: string;
  year: number;
  ghgIntensity: number;
  fuelConsumption: number;
  distance: number;
  totalEmissions: number;
  isBaseline: boolean;
};

export interface RouteRepository {
  findAll(): Promise<RouteRecord[]>;
  findByRouteId(routeId: string): Promise<RouteRecord | null>;
  setBaseline(routeId: string): Promise<void>;
  findBaseline(): Promise<RouteRecord | null>;
}

export interface ComplianceRepository {
  upsertSnapshot(shipId: string, year: number, cbGco2eq: number): Promise<void>;
  findSnapshot(shipId: string, year: number): Promise<{ cbGco2eq: number } | null>;
}

export type BankEntryRecord = {
  id: string;
  shipId: string;
  year: number;
  amountGco2eq: number;
  entryType: string;
  createdAt: Date;
};

export interface BankRepository {
  createEntry(input: {
    shipId: string;
    year: number;
    amountGco2eq: number;
    entryType: string;
  }): Promise<BankEntryRecord>;
  listForShipYear(shipId: string, year: number): Promise<BankEntryRecord[]>;
  /** Sum(BANK) − Sum(APPLY) for the year (fleet-wide pool). */
  fleetBankBalanceForYear(year: number): Promise<number>;
}

export interface PoolRepository {
  createPoolWithMembers(input: {
    year: number;
    members: { shipId: string; cbBefore: number; cbAfter: number }[];
  }): Promise<{ poolId: string }>;
}
