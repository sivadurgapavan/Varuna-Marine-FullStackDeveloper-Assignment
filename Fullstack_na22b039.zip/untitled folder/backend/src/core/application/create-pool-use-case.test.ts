import { describe, expect, it } from "vitest";
import { createPool } from "./create-pool-use-case.js";
import { createInMemoryPoolRepo } from "../../test/in-memory-repos.js";

describe("createPool", () => {
  it("creates pool when rules pass", async () => {
    const poolRepo = createInMemoryPoolRepo();
    const r = await createPool(poolRepo, 2024, [
      { shipId: "A", cbBefore: 50 },
      { shipId: "B", cbBefore: -20 },
    ]);
    expect(r.poolId).toBeDefined();
    expect(r.members).toHaveLength(2);
  });

  it("rejects when sum of CB is negative", async () => {
    const poolRepo = createInMemoryPoolRepo();
    await expect(
      createPool(poolRepo, 2024, [
        { shipId: "A", cbBefore: -50 },
        { shipId: "B", cbBefore: -20 },
      ])
    ).rejects.toThrow();
  });
});
