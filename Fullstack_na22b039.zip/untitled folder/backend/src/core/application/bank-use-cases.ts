import { BANK_ENTRY_APPLY, BANK_ENTRY_BANK } from "../domain/constants.js";
import type { BankRepository, ComplianceRepository, RouteRepository } from "../ports/repositories.js";
import {
  adjustedComplianceForShipYear,
  computeRouteComplianceCb,
} from "./compliance-service.js";

export type BankSurplusResult = {
  cbBefore: number;
  banked: number;
  cbAfter: number;
  fleetBankBalance: number;
};

export async function bankSurplus(
  routeRepo: RouteRepository,
  complianceRepo: ComplianceRepository,
  bankRepo: BankRepository,
  shipId: string,
  year: number,
  amount?: number
): Promise<BankSurplusResult> {
  const routes = await routeRepo.findAll();
  const route = routes.find((r) => r.shipId === shipId && r.year === year);
  if (!route) {
    throw new Error(`No route for ship ${shipId} in ${year}`);
  }
  const raw = computeRouteComplianceCb(route);
  await complianceRepo.upsertSnapshot(shipId, year, raw);
  const cbBefore = await adjustedComplianceForShipYear(
    raw,
    bankRepo,
    shipId,
    year
  );
  if (cbBefore <= 0) {
    throw new Error("Cannot bank: compliance balance is not positive");
  }
  const toBank = amount !== undefined ? Math.min(amount, cbBefore) : cbBefore;
  if (toBank <= 0) {
    throw new Error("Nothing to bank");
  }
  await bankRepo.createEntry({
    shipId,
    year,
    amountGco2eq: toBank,
    entryType: BANK_ENTRY_BANK,
  });
  const cbAfter = cbBefore - toBank;
  const fleetBankBalance = await bankRepo.fleetBankBalanceForYear(year);
  return { cbBefore, banked: toBank, cbAfter, fleetBankBalance };
}

export type ApplyBankedResult = {
  cbBefore: number;
  applied: number;
  cbAfter: number;
  fleetBankBalance: number;
};

export async function applyBankedSurplus(
  routeRepo: RouteRepository,
  complianceRepo: ComplianceRepository,
  bankRepo: BankRepository,
  shipId: string,
  year: number,
  amount: number
): Promise<ApplyBankedResult> {
  if (amount <= 0) {
    throw new Error("Apply amount must be positive");
  }
  const routes = await routeRepo.findAll();
  const route = routes.find((r) => r.shipId === shipId && r.year === year);
  if (!route) {
    throw new Error(`No route for ship ${shipId} in ${year}`);
  }
  const raw = computeRouteComplianceCb(route);
  await complianceRepo.upsertSnapshot(shipId, year, raw);
  const cbBefore = await adjustedComplianceForShipYear(
    raw,
    bankRepo,
    shipId,
    year
  );
  if (cbBefore >= 0) {
    throw new Error("Apply is only for deficit positions (negative CB)");
  }
  const need = -cbBefore;
  const toApply = Math.min(amount, need);
  const available = await bankRepo.fleetBankBalanceForYear(year);
  if (toApply > available + 1e-6) {
    throw new Error(
      `Apply amount exceeds available banked surplus (available ${available})`
    );
  }
  await bankRepo.createEntry({
    shipId,
    year,
    amountGco2eq: toApply,
    entryType: BANK_ENTRY_APPLY,
  });
  const cbAfter = cbBefore + toApply;
  const fleetBankBalance = await bankRepo.fleetBankBalanceForYear(year);
  return { cbBefore, applied: toApply, cbAfter, fleetBankBalance };
}
