import { BANK_ENTRY_APPLY, BANK_ENTRY_BANK } from "../domain/constants.js";
import {
  computeComplianceBalanceGco2eq,
  computePercentDiffVsBaseline,
  isCompliantWithTarget,
} from "../domain/compliance.js";
import { TARGET_INTENSITY_GCO2E_PER_MJ } from "../domain/constants.js";
import type { BankRepository, ComplianceRepository, RouteRecord } from "../ports/repositories.js";

export function computeRouteComplianceCb(route: RouteRecord): number {
  return computeComplianceBalanceGco2eq(route.ghgIntensity, route.fuelConsumption);
}

export async function getOrCreateComplianceSnapshot(
  complianceRepo: ComplianceRepository,
  route: RouteRecord
): Promise<number> {
  const cb = computeRouteComplianceCb(route);
  await complianceRepo.upsertSnapshot(route.shipId, route.year, cb);
  return cb;
}

export async function adjustedComplianceForShipYear(
  complianceCb: number,
  bankRepo: BankRepository,
  shipId: string,
  year: number
): Promise<number> {
  const entries = await bankRepo.listForShipYear(shipId, year);
  let delta = 0;
  for (const e of entries) {
    if (e.entryType === BANK_ENTRY_BANK) {
      delta -= e.amountGco2eq;
    } else if (e.entryType === BANK_ENTRY_APPLY) {
      delta += e.amountGco2eq;
    }
  }
  return complianceCb + delta;
}

export type ComparisonRow = {
  routeId: string;
  vesselType: string;
  fuelType: string;
  year: number;
  ghgIntensity: number;
  percentDiff: number;
  compliant: boolean;
};

export function buildComparisonRows(
  baseline: RouteRecord,
  others: RouteRecord[]
): ComparisonRow[] {
  return others.map((r) => ({
    routeId: r.routeId,
    vesselType: r.vesselType,
    fuelType: r.fuelType,
    year: r.year,
    ghgIntensity: r.ghgIntensity,
    percentDiff: computePercentDiffVsBaseline(baseline.ghgIntensity, r.ghgIntensity),
    compliant: isCompliantWithTarget(r.ghgIntensity, TARGET_INTENSITY_GCO2E_PER_MJ),
  }));
}
