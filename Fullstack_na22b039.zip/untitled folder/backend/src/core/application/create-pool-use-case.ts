import { allocatePoolGreedy, validatePoolRules } from "../domain/pool-allocation.js";
import type { PoolRepository } from "../ports/repositories.js";

export async function createPool(
  poolRepo: PoolRepository,
  year: number,
  members: { shipId: string; cbBefore: number }[]
): Promise<{ poolId: string; members: { shipId: string; cbBefore: number; cbAfter: number }[] }> {
  if (members.length < 2) {
    throw new Error("Pool requires at least two members");
  }
  const sumBefore = members.reduce((s, m) => s + m.cbBefore, 0);
  if (sumBefore < -1e-6) {
    throw new Error("Sum of adjusted CB must be ≥ 0 to form a pool");
  }
  const allocated = allocatePoolGreedy(members);
  const rules = validatePoolRules(allocated);
  if (!rules.ok) {
    throw new Error(rules.reason);
  }
  const { poolId } = await poolRepo.createPoolWithMembers({
    year,
    members: allocated.map((m) => ({
      shipId: m.shipId,
      cbBefore: m.cbBefore,
      cbAfter: m.cbAfter,
    })),
  });
  return { poolId, members: allocated };
}
