import { describe, expect, it } from "vitest";
import { bankSurplus, applyBankedSurplus } from "./bank-use-cases.js";
import {
  createInMemoryBankRepo,
  createInMemoryComplianceRepo,
  createInMemoryRouteRepo,
  sampleRoute,
} from "../../test/in-memory-repos.js";
import type { RouteRecord } from "../ports/repositories.js";

function surplusForS002(): RouteRecord {
  return {
    ...sampleRoute,
    routeId: "R002",
    shipId: "S002",
    ghgIntensity: 85,
    fuelConsumption: 1000,
    isBaseline: false,
  };
}

function deficitForS001(): RouteRecord {
  return {
    ...sampleRoute,
    routeId: "R001",
    shipId: "S001",
    ghgIntensity: 95,
    fuelConsumption: 1000,
    isBaseline: true,
  };
}

describe("bankSurplus", () => {
  it("banks positive adjusted CB", async () => {
    const routeRepo = createInMemoryRouteRepo([
      {
        ...sampleRoute,
        ghgIntensity: 85,
        fuelConsumption: 1000,
      },
    ]);
    const complianceRepo = createInMemoryComplianceRepo();
    const bankRepo = createInMemoryBankRepo();
    const r = await bankSurplus(
      routeRepo,
      complianceRepo,
      bankRepo,
      "S001",
      2024
    );
    expect(r.banked).toBeGreaterThan(0);
    expect(r.cbAfter).toBeCloseTo(r.cbBefore - r.banked, 4);
  });
});

describe("applyBankedSurplus", () => {
  it("applies fleet bank to a deficit ship", async () => {
    const routeRepo = createInMemoryRouteRepo([
      deficitForS001(),
      surplusForS002(),
    ]);
    const complianceRepo = createInMemoryComplianceRepo();
    const bankRepo = createInMemoryBankRepo();
    await bankSurplus(routeRepo, complianceRepo, bankRepo, "S002", 2024);
    const apply = await applyBankedSurplus(
      routeRepo,
      complianceRepo,
      bankRepo,
      "S001",
      2024,
      1e15
    );
    expect(apply.applied).toBeGreaterThan(0);
    expect(apply.cbAfter).toBeGreaterThan(apply.cbBefore);
  });
});
