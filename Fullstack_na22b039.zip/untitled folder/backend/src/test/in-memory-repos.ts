import { randomUUID } from "node:crypto";
import { BANK_ENTRY_APPLY, BANK_ENTRY_BANK } from "../core/domain/constants.js";
import type {
  BankEntryRecord,
  BankRepository,
  ComplianceRepository,
  PoolRepository,
  RouteRecord,
  RouteRepository,
} from "../core/ports/repositories.js";

export function createInMemoryRouteRepo(
  initial: RouteRecord[]
): RouteRepository {
  const routes = initial.map((r) => ({ ...r }));
  return {
    async findAll() {
      return routes.map((r) => ({ ...r }));
    },
    async findByRouteId(routeId: string) {
      const r = routes.find((x) => x.routeId === routeId);
      return r ? { ...r } : null;
    },
    async setBaseline(routeId: string) {
      routes.forEach((r) => {
        r.isBaseline = r.routeId === routeId;
      });
    },
    async findBaseline() {
      const r = routes.find((x) => x.isBaseline);
      return r ? { ...r } : null;
    },
  };
}

export function createInMemoryComplianceRepo(): ComplianceRepository {
  const map = new Map<string, number>();
  const key = (shipId: string, year: number) => `${shipId}:${year}`;
  return {
    async upsertSnapshot(shipId: string, year: number, cbGco2eq: number) {
      map.set(key(shipId, year), cbGco2eq);
    },
    async findSnapshot(shipId: string, year: number) {
      const v = map.get(key(shipId, year));
      return v !== undefined ? { cbGco2eq: v } : null;
    },
  };
}

export function createInMemoryBankRepo(): BankRepository {
  const entries: BankEntryRecord[] = [];
  return {
    async createEntry(input) {
      const e: BankEntryRecord = {
        id: randomUUID(),
        shipId: input.shipId,
        year: input.year,
        amountGco2eq: input.amountGco2eq,
        entryType: input.entryType,
        createdAt: new Date(),
      };
      entries.push(e);
      return e;
    },
    async listForShipYear(shipId: string, year: number) {
      return entries.filter((e) => e.shipId === shipId && e.year === year);
    },
    async fleetBankBalanceForYear(year: number) {
      let banked = 0;
      let applied = 0;
      for (const e of entries) {
        if (e.year !== year) continue;
        if (e.entryType === BANK_ENTRY_BANK) banked += e.amountGco2eq;
        if (e.entryType === BANK_ENTRY_APPLY) applied += e.amountGco2eq;
      }
      return banked - applied;
    },
  };
}

export function createInMemoryPoolRepo(): PoolRepository {
  return {
    async createPoolWithMembers() {
      return { poolId: randomUUID() };
    },
  };
}

export const sampleRoute: RouteRecord = {
  id: "rid",
  routeId: "R001",
  shipId: "S001",
  vesselType: "Container",
  fuelType: "HFO",
  year: 2024,
  ghgIntensity: 91.0,
  fuelConsumption: 5000,
  distance: 12000,
  totalEmissions: 4500,
  isBaseline: true,
};
