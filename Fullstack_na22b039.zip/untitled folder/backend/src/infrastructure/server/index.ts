import { PrismaClient } from "@prisma/client";
import { createApp } from "../../adapters/inbound/http/create-app.js";
import {
  createBankRepository,
  createComplianceRepository,
  createPoolRepository,
  createRouteRepository,
} from "../../adapters/outbound/postgres/prisma-repositories.js";

const prisma = new PrismaClient();
const routeRepo = createRouteRepository(prisma);
const complianceRepo = createComplianceRepository(prisma);
const bankRepo = createBankRepository(prisma);
const poolRepo = createPoolRepository(prisma);

const app = createApp({ routeRepo, complianceRepo, bankRepo, poolRepo });
const port = Number(process.env.PORT) || 4000;

app.listen(port, () => {
  console.log(`Fuel EU Maritime API listening on http://localhost:${port}`);
});
