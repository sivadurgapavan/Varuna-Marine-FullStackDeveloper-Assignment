import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const seedRoutes = [
  {
    routeId: "R001",
    shipId: "S001",
    vesselType: "Container",
    fuelType: "HFO",
    year: 2024,
    ghgIntensity: 91.0,
    fuelConsumption: 5000,
    distance: 12000,
    totalEmissions: 4500,
    isBaseline: true,
  },
  {
    routeId: "R002",
    shipId: "S002",
    vesselType: "BulkCarrier",
    fuelType: "LNG",
    year: 2024,
    ghgIntensity: 88.0,
    fuelConsumption: 4800,
    distance: 11500,
    totalEmissions: 4200,
    isBaseline: false,
  },
  {
    routeId: "R003",
    shipId: "S003",
    vesselType: "Tanker",
    fuelType: "MGO",
    year: 2024,
    ghgIntensity: 93.5,
    fuelConsumption: 5100,
    distance: 12500,
    totalEmissions: 4700,
    isBaseline: false,
  },
  {
    routeId: "R004",
    shipId: "S004",
    vesselType: "RoRo",
    fuelType: "HFO",
    year: 2025,
    ghgIntensity: 89.2,
    fuelConsumption: 4900,
    distance: 11800,
    totalEmissions: 4300,
    isBaseline: false,
  },
  {
    routeId: "R005",
    shipId: "S005",
    vesselType: "Container",
    fuelType: "LNG",
    year: 2025,
    ghgIntensity: 90.5,
    fuelConsumption: 4950,
    distance: 11900,
    totalEmissions: 4400,
    isBaseline: false,
  },
];

async function main() {
  await prisma.bankEntry.deleteMany();
  await prisma.poolMember.deleteMany();
  await prisma.pool.deleteMany();
  await prisma.shipCompliance.deleteMany();
  await prisma.route.deleteMany();
  await prisma.ship.deleteMany();

  const ships = [
    { shipId: "S001", name: "MV Alpha" },
    { shipId: "S002", name: "MV Beta" },
    { shipId: "S003", name: "MV Gamma" },
    { shipId: "S004", name: "MV Delta" },
    { shipId: "S005", name: "MV Epsilon" },
  ];
  for (const s of ships) {
    await prisma.ship.create({ data: s });
  }
  for (const r of seedRoutes) {
    await prisma.route.create({ data: r });
  }
}

main()
  .then(() => prisma.$disconnect())
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
